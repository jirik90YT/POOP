import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import WebSocket from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3000;
const PO_WS = process.env.PO_WS || 'wss://api-c.po.market/socket.io/?EIO=4&transport=websocket';
const SSID = process.env.PO_SSID || '';
const IS_DEMO = (process.env.PO_DEMO === '1');

const app = express();
app.use(cors());
app.use(express.json());

// Serve built client on production
const clientDist = path.resolve(__dirname, '../client/dist');
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(clientDist));
}

let latestCandlesBySymbol = {};
let lastSignal = { kind: '⚪ NEKUPUJ', symbol: null, mode: 'NORMAL', reason: 'init', time: Date.now() };
let active = { symbol: 'EURUSD', timeframe: 'M1', mode: 'NORMAL' };

let ws = null;
let pingInterval = null;

const k = (symbol, mode) => `${symbol}__${mode}`;

const sma = (arr, period) => {
  if (!arr || arr.length < period) return null;
  let sum = 0;
  for (let i = arr.length - period; i < arr.length; i++) sum += arr[i].c;
  return sum / period;
};

function evaluateStrategy(symbol, mode) {
  const arr = latestCandlesBySymbol[k(symbol, mode)] || [];
  if (arr.length < 25) return;
  const fast = sma(arr, 5);
  const slow = sma(arr, 20);
  if (fast == null || slow == null) return;

  let kind = '⚪ NEKUPUJ';
  let reason = `SMA5(${fast.toFixed(5)}) vs SMA20(${slow.toFixed(5)})`;
  if (fast > slow * 1.0002) kind = '🟢 BUY';
  if (fast < slow * 0.9998) kind = '🔴 SELL';

  lastSignal = { kind, symbol, mode, reason, time: Date.now() };
}

function connect() {
  if (ws) try { ws.close(); } catch {}
  console.log('[WS] Connecting to', PO_WS);
  ws = new WebSocket(PO_WS, {
    headers: { 'User-Agent': 'Mozilla/5.0 PocketSignals/1.0' }
  });

  ws.on('open', () => {
    console.log('[WS] open, sending 40 + auth');
    ws.send('40');
    setTimeout(() => {
      if (SSID) {
        ws.send(SSID);
        console.log('[WS] auth sent');
      } else {
        console.warn('[WS] PO_SSID is empty. Fill it in server/.env');
      }
      subscribeActive();
    }, 400);

    if (pingInterval) clearInterval(pingInterval);
    pingInterval = setInterval(() => { try { ws.send('2'); } catch {} }, 25000);
  });

  ws.on('message', (buf) => {
    const s = buf.toString();
    if (s.startsWith('42')) {
      try {
        const payload = JSON.parse(s.slice(2));
        const evt = payload[0];
        const body = payload[1];

        if (evt === 'candles' || evt === 'update.candles') {
          if (body && body.instrument && Array.isArray(body.candles)) {
            const mode = body.otc ? 'OTC' : 'NORMAL';
            const key = k(body.instrument, mode);
            const normalized = body.candles.map(c => ({
              t: c.t || c.time || c[0],
              o: + (c.o ?? c.open ?? c[1]),
              h: + (c.h ?? c.high ?? c[2]),
              l: + (c.l ?? c.low  ?? c[3]),
              c: + (c.c ?? c.close?? c[4])
            }));
            latestCandlesBySymbol[key] = normalized.slice(-200);
            evaluateStrategy(body.instrument, mode);
          }
        }
      } catch {}
    }
  });

  ws.on('close', () => {
    console.log('[WS] closed. Reconnecting in 3s...');
    if (pingInterval) clearInterval(pingInterval);
    setTimeout(connect, 3000);
  });

  ws.on('error', (err) => console.error('[WS] error', err.message));
}

function subscribeActive() {
  const sub = ["subscribe", { instrument: active.symbol, timeframe: active.timeframe, otc: active.mode === 'OTC' ? 1 : 0 }];
  try {
    ws?.send('42' + JSON.stringify(sub));
    console.log('[WS] subscribe', sub);
  } catch (e) {
    console.warn('[WS] subscribe failed', e.message);
  }
}

// API
app.get('/health', (_req, res) => res.json({ ok: true, active, lastSignal }));

app.post('/api/switch', (req, res) => {
  const { symbol, timeframe, mode } = req.body || {};
  if (symbol) active.symbol = symbol;
  if (timeframe) active.timeframe = timeframe;
  if (mode && (mode === 'NORMAL' || mode === 'OTC')) active.mode = mode;
  subscribeActive();
  res.json({ ok: true, active });
});

app.get('/api/stream', (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive'
  });
  const push = () => { res.write(`data: ${JSON.stringify({ lastSignal, active })}\n\n`); };
  const interval = setInterval(push, 1500);
  req.on('close', () => clearInterval(interval));
  push();
});

// Fallback to index.html on production
if (process.env.NODE_ENV === 'production') {
  app.get('*', (req, res) => {
    res.sendFile(path.join(clientDist, 'index.html'));
  });
}

app.listen(PORT, () => {
  console.log('Server listening on :' + PORT);
  connect();
});
