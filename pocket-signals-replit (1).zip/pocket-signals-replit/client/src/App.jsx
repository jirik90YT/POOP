import React, { useEffect, useRef, useState } from 'react'

function StatusPill({ text }) {
  const color = text.startsWith('🟢') ? '#22c55e' : text.startsWith('🔴') ? '#ef4444' : '#6b7280';
  return (
    <span style={{ padding: '6px 10px', borderRadius: 999, background: '#111', color, fontWeight: 700 }}>
      {text}
    </span>
  )
}

export default function App() {
  const [last, setLast] = useState(null);
  const [symbol, setSymbol] = useState('EURUSD');
  const [timeframe, setTimeframe] = useState('M1');
  const [mode, setMode] = useState('NORMAL'); // NORMAL | OTC
  const logRef = useRef([]);

  useEffect(() => {
    const es = new EventSource('/api/stream');
    es.onmessage = (evt) => {
      try {
        const data = JSON.parse(evt.data);
        setLast(data);
        if (data?.lastSignal) {
          logRef.current = [{ time: new Date(data.lastSignal.time).toLocaleTimeString(), kind: data.lastSignal.kind, sym: data.lastSignal.symbol, mode: data.lastSignal.mode }, ...logRef.current].slice(0, 50);
        }
      } catch {}
    }
    return () => es.close();
  }, []);

  const onSwitch = async () => {
    await fetch('/api/switch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ symbol, timeframe, mode })
    });
  };

  const active = last?.active || { symbol, timeframe, mode };

  return (
    <div style={{ minHeight: '100vh', background: '#0b0b0f', color: '#e5e7eb', padding: 24, fontFamily: 'Inter, system-ui, sans-serif' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h1 style={{ fontSize: 24, fontWeight: 800 }}>Pocket Signals</h1>
        <div title="Real-time signal">
          <StatusPill text={last?.lastSignal?.kind || '⚪ NEKUPUJ'} />
        </div>
      </header>

      <section style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div style={{ background: '#111318', borderRadius: 16, padding: 16 }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12 }}>Aktivní nastavení</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <label style={{ display: 'grid', gap: 6 }}>
              <span>Symbol</span>
              <input value={symbol} onChange={(e)=>setSymbol(e.target.value)} style={{ background:'#0c0e13', color:'#fff', border:'1px solid #20242f', borderRadius:8, padding:8 }} />
            </label>
            <label style={{ display: 'grid', gap: 6 }}>
              <span>Timeframe</span>
              <select value={timeframe} onChange={(e)=>setTimeframe(e.target.value)} style={{ background:'#0c0e13', color:'#fff', border:'1px solid #20242f', borderRadius:8, padding:8 }}>
                <option value="M1">M1</option>
                <option value="M5">M5</option>
                <option value="M15">M15</option>
              </select>
            </label>
            <label style={{ display: 'grid', gap: 6 }}>
              <span>Režim</span>
              <select value={mode} onChange={(e)=>setMode(e.target.value)} style={{ background:'#0c0e13', color:'#fff', border:'1px solid #20242f', borderRadius:8, padding:8 }}>
                <option value="NORMAL">Normální měna</option>
                <option value="OTC">OTC</option>
              </select>
            </label>
            <div style={{ display:'flex', alignItems:'end' }}>
              <button onClick={onSwitch} style={{ padding:'10px 14px', background:'#2563eb', border:'none', color:'#fff', borderRadius:10, fontWeight:700, cursor:'pointer' }}>Přepnout</button>
            </div>
          </div>

          <div style={{ marginTop: 12, fontSize: 13, color:'#a1a1aa' }}>
            <div>Aktivní: <b>{active.symbol}</b> / <b>{active.timeframe}</b> / <b>{active.mode}</b></div>
            <div>Poslední důvod: <i>{last?.lastSignal?.reason || '—'}</i></div>
          </div>
        </div>

        <div style={{ background: '#111318', borderRadius: 16, padding: 16 }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12 }}>Log signálů</h2>
          <div style={{ display:'grid', gap:8, maxHeight: 320, overflow:'auto' }}>
            {logRef.current.map((row, idx) => (
              <div key={idx} style={{ display:'grid', gridTemplateColumns:'80px 90px 1fr', gap:8, background:'#0e1016', border:'1px solid #1f2633', borderRadius:10, padding:'6px 10px' }}>
                <span style={{ color:'#a1a1aa' }}>{row.time}</span>
                <span>{row.mode}</span>
                <b>{row.kind} {row.sym}</b>
              </div>
            ))}
            {logRef.current.length === 0 && <div style={{ color:'#9ca3af' }}>Zatím žádná data…</div>}
          </div>
        </div>
      </section>

      <footer style={{ marginTop: 16, fontSize: 12, color:'#9ca3af' }}>
        <p>Deployment pro Replit: první spuštění automaticky nainstaluje závislosti, postaví frontend a spustí server na portu 3000.</p>
      </footer>
    </div>
  )
}
